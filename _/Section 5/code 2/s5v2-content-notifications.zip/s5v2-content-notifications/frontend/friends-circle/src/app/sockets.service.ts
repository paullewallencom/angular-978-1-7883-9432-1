import { Injectable } from '@angular/core';
import Echo from 'laravel-echo';
import { User } from '../entities/User';
import { EventEmitter } from '@angular/core';

export class PostCreatedEvent {
  post : any
  author : any
}

@Injectable()
export class SocketsService {
  echo : Echo = null
  user : User = null

  public postCreatedEventFired = new EventEmitter<PostCreatedEvent>()

  setup(token : string, user : User) {
    if (!token || !user) {
      this.echo = null;

      return;
    }

    this.user = user;

    this.echo = new Echo({
      broadcaster: 'socket.io',
      host: 'http://localhost:6001',
      auth: {
          headers: {
              'Authorization': 'Bearer ' + token
          }
      }
    });

    this.listen();
  }

  listen() {
    this.echo.private(`App.User.${this.user.id}`)
      .listen(
        'PostCreated',
        (event) => this.postCreatedEventFired.emit(event)
      );
  }
}
