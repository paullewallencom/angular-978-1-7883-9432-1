import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';

import { MatInputModule, MatIconModule, MatButtonModule } from '@angular/material';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatCardModule } from '@angular/material/card';

import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';

import { AuthService } from './auth.service';
import { NetworkService } from './network.service';
import { LoginComponent } from './login/login.component';
import { SocialFeedComponent } from './social-feed/social-feed.component';
import { AddEntryComponent } from './add-entry/add-entry.component';
import { SinglePostComponent } from './single-post/single-post.component';
import { UsersFriendsComponent } from './users-friends/users-friends.component';
import { SocketsService } from './sockets.service';
import { PostService } from './post.service';
import { UserService } from './user.service';

const appRoutes : Routes = [
  {
    path: 'register',
    component: RegisterComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'feed',
    component: SocialFeedComponent
  },
  {
    path: 'users',
    component: UsersFriendsComponent
  },
  {
    path: '',
    redirectTo: '/register',
    pathMatch: 'full'
  }
];

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    SocialFeedComponent,
    AddEntryComponent,
    SinglePostComponent,
    UsersFriendsComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes, {
      enableTracing: true
    }),
    BrowserAnimationsModule,
    MatInputModule,
    MatFormFieldModule,
    MatIconModule,
    FormsModule,
    HttpClientModule,
    MatCardModule,
    MatButtonModule
  ],
  providers: [
    AuthService,
    NetworkService,
    SocketsService,
    PostService,
    UserService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
