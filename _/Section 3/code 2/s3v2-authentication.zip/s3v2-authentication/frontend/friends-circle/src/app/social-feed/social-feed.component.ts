import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { User } from '../../entities/User';

@Component({
  selector: 'app-social-feed',
  templateUrl: './social-feed.component.html',
  styleUrls: ['./social-feed.component.scss']
})
export class SocialFeedComponent implements OnInit {
  currentUser : User

  constructor(
    private _auth : AuthService
  ) { }

  async ngOnInit() {
    const currentUser = await this._auth.fetchCurrentUserInfo();

    this.currentUser = currentUser;
  }

  addEntry(entry) {
    alert(entry.content);
  }

}
