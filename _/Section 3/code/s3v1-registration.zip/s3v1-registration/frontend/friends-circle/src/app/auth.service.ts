import { Injectable } from '@angular/core';
import { User } from '../entities/User';
import { HttpClient } from '@angular/common/http';

const BACKEND_DOMAIN = 'http://localhost';

@Injectable()
export class AuthService {

  constructor(private _http : HttpClient) { }

  register(user : User) {
    return this._http.post(this.buildURL('/api/register'), {
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      password: user.password
    }).toPromise();
  }

  login(user : User) {
    return this._http.post(this.buildURL('/auth'), {
      username: user.email,
      password: user.password
    }).toPromise();
  }

  buildURL(path) {
    return BACKEND_DOMAIN + path;
  }
}
