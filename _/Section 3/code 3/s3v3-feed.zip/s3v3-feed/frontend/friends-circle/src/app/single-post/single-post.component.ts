import { Component, OnInit, Input } from '@angular/core';
import { Post } from '../../entities/Post';
import { NetworkService } from '../network.service';
import { User } from '../../entities/User';
import * as moment from 'moment';

@Component({
  selector: 'app-single-post',
  templateUrl: './single-post.component.html',
  styleUrls: ['./single-post.component.scss']
})
export class SinglePostComponent implements OnInit {
  @Input() post : Post

  author : User

  timePassed

  constructor(
    private _network : NetworkService
  ) { }

  ngOnInit() {
    this.getUserDetails();

    this.timePassed = moment(this.post.createdAt).fromNow();
  }

  async getUserDetails() {
    const response = await this._network.request(
      'get',
      `users/${this.post.authorId}`
    );

    this.author = new User(response['firstName'], response['lastName']);
  }

}
