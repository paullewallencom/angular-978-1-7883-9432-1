<?php

namespace Tests\Feature;

use \App\User;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;

class FriendshipTest extends TestCase
{
    use RefreshDatabase;

    public function testAddFriendReturnsErrorIfTryingToAddYourself()
    {
        $user = factory(User::class)->create();

        $this->assertEquals($user->friends()->count(), 0);

        $response = $this->actingAs($user)
            ->post('/api/users/' . $user->id . '/add_friend')
            ->assertStatus(400)
            ->assertJson([
                'error' => "You can't add yourself to friends."
            ]);

        $this->assertEquals($user->friends()->count(), 0);
    }

    public function testAddFriendAddsFriendIfNotPresent()
    {
        $user = factory(User::class)->create();
        $otherUser = factory(User::class)->create();

        $this->assertEquals($user->friends()->count(), 0);

        $this->actingAs($user)
            ->post('api/users/' . $otherUser->id . '/add_friend')
            ->assertStatus(200)
            ->assertJson([
                'success' => true
            ]);
        
        $this->assertEquals($user->friends()->count(), 1);        
    }
}
