import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';

import { SinglePostComponent } from './single-post.component';
import { MatIconModule, MatCardModule } from '@angular/material';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { UserService } from '../user.service';
import { NetworkService } from '../network.service';
import { AuthService } from '../auth.service';
import { SocketsService } from '../sockets.service';
import { Post } from '../../entities/Post';
import { User } from '../../entities/User';
import { By } from '@angular/platform-browser';

describe('SinglePostComponent', () => {
  let component: SinglePostComponent;
  let fixture: ComponentFixture<SinglePostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        SinglePostComponent
      ],
      providers: [
        UserService,
        NetworkService,
        AuthService,
        SocketsService
      ],
      imports: [
        MatIconModule,
        MatCardModule,
        HttpClientModule,
        RouterTestingModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SinglePostComponent);
    component = fixture.componentInstance;
  });

  fit('should create', inject([UserService], async (userService : UserService) => {
    const AUTHOR_ID = 233;
    const POST_CONTENT = 'This is post content. Hello friends!';

    const TEST_AUTHOR = new User(
      'Daniel',
      'Kmak'
    );

    component.post = new Post({
      id: 1,
      content: POST_CONTENT,
      authorId: AUTHOR_ID
    });

    userService.getUserDetails = (id) => {
      expect(id).toEqual(AUTHOR_ID);

      return Promise.resolve(TEST_AUTHOR);
    };

    await component.ngOnInit();

    fixture.detectChanges();

    expect(component).toBeTruthy();

    const singlePostElement = fixture.debugElement.query(By.css('.social-feed-card'));

    const cardContent = singlePostElement.query(By.css('mat-card-content'));

    expect(cardContent.nativeElement.textContent.trim()).toBe(POST_CONTENT);

    const cardTitle = singlePostElement.query(By.css('mat-card-title'));

    expect(cardTitle.nativeElement.textContent.trim()).toBe(TEST_AUTHOR.fullName);
  }));
});
