import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { User } from '../../entities/User';
import { Post } from '../../entities/Post';
import { Router } from '@angular/router';
import { PostService } from '../post.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-social-feed',
  templateUrl: './social-feed.component.html',
  styleUrls: ['./social-feed.component.scss']
})
export class SocialFeedComponent implements OnInit {
  currentUser : User
  posts : Post[]

  constructor(
    private _auth : AuthService,
    private _router : Router,
    private _postService : PostService
  ) { }

  async ngOnInit() {
    const currentUser = await this._auth.fetchCurrentUserInfo();

    this.currentUser = currentUser;

    await this._postService.fetchPosts();

    this.posts = this._postService.posts;

    this.addEntry = this.addEntry.bind(this);
  }

  async addEntry(entry) {
    return this._postService.addPost(entry);
  }

  async logout() {
    this._auth.logout();
  }
}
