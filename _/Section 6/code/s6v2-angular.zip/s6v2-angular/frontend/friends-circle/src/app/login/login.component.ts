import { Component, OnInit } from '@angular/core';
import { User } from '../../entities/User';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  public model : User

  constructor(
    private _auth : AuthService,
    private _router : Router
  ) { }

  ngOnInit() {
    this.model = new User();
  }

  async login() {
    const success = await this._auth.login(this.model);

    if (success) {
      this._router.navigate(['feed']);
    } else {
      alert('Bad credentials.');
    }
  }

}
