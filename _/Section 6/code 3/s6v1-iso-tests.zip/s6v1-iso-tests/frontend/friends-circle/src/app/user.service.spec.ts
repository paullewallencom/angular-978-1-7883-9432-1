import { TestBed, inject } from '@angular/core/testing';

import { UserService } from './user.service';
import { NetworkService } from './network.service';
import { AuthService } from './auth.service';
import { SocketsService, FriendAddedEvent } from './sockets.service';
import { HttpClientModule } from '@angular/common/http';

import { RouterTestingModule } from '@angular/router/testing';
import { User } from '../entities/User';

describe('UserService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        UserService,
        NetworkService,
        AuthService,
        SocketsService
      ],
      imports: [
        HttpClientModule,
        RouterTestingModule
      ]
    });
  });

  fit('should be created', inject([UserService], (service: UserService) => {
    expect(service).toBeTruthy();
  }));

  fit(
    'should subscribe to SocketsService friendAddedEventFired and friendRemovedEventFired',
    inject([UserService, SocketsService], (service: UserService, socketsService : SocketsService) => {
      expect(socketsService.friendAddedEventFired.observers.length).toEqual(1);
      expect(socketsService.friendRemovedEventFired.observers.length).toEqual(1);
  }));

  fit(
    'handleFriendAddedEvent adds event initiator to friends if not present',
    inject([UserService, AuthService], (service: UserService, authService : AuthService) => {
      const currentUser = new User('Daniel', 'Kmak');

      const INITIATOR_ID = 7;

      const friendAddedEvent = {
        initiator: {
          id: INITIATOR_ID
        }
      } as FriendAddedEvent;

      authService.currentUser = currentUser;

      expect(currentUser.friends.length).toEqual(0);

      service.handleFriendAddedEvent(friendAddedEvent);

      expect(currentUser.friends.length).toEqual(1);

      service.handleFriendAddedEvent(friendAddedEvent);

      expect(currentUser.friends.length).toEqual(1);
  }));

});
