import { Component, OnInit, Input } from '@angular/core';
import { Post } from '../../entities/Post';
import { User } from '../../entities/User';
import * as moment from 'moment';
import { UserService } from '../user.service';

@Component({
  selector: 'app-single-post',
  templateUrl: './single-post.component.html',
  styleUrls: ['./single-post.component.scss']
})
export class SinglePostComponent implements OnInit {
  @Input() post : Post

  author : User

  timePassed

  constructor(
    private _userService : UserService
  ) { }

  async ngOnInit() {
    this.author = await this._userService.getUserDetails(this.post.authorId);

    this.timePassed = moment(this.post.createdAt).fromNow();
  }
}
