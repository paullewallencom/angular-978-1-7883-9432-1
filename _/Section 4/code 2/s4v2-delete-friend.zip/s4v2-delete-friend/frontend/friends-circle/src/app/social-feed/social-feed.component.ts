import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { User } from '../../entities/User';
import { Post } from '../../entities/Post';
import { NetworkService } from '../network.service';

@Component({
  selector: 'app-social-feed',
  templateUrl: './social-feed.component.html',
  styleUrls: ['./social-feed.component.scss']
})
export class SocialFeedComponent implements OnInit {
  currentUser : User
  posts : Post[]

  constructor(
    private _auth : AuthService,
    private _network : NetworkService
  ) { }

  async ngOnInit() {
    const currentUser = await this._auth.fetchCurrentUserInfo();

    this.currentUser = currentUser;

    this.posts = await this.getPosts();

    this.addEntry = this.addEntry.bind(this);
  }

  async addEntry(entry) {
    const response = await this._network.request('post', 'posts', {
      body: {
        content: entry.content
      }
    });

    this.posts.push(new Post({
      authorId: response['author_id'],
      content: response['content'],
      createdAt: response['created_at']
    }));
  }

  async getPosts() {
    const response = await this._network.request('get', 'posts') as Array<any>;

    return response.map(item => new Post({
      authorId: item.author_id,
      content: item.content,
      createdAt: item.created_at
    }));
  }
}
